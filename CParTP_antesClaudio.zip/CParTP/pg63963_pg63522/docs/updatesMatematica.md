# Potential fundido no computeAccelerations

## Problema encontrado:

O Potential() é um segundo ciclo O(N²) (12.5 M pares por passo) que repete o trabalho do computeAccelerations():
os mesmos dx, dy, dz, o mesmo r2 e a mesma 1/r2 (frecpe + Newton), sobre as mesmas posições. As posições não mudam
entre os dois no ciclo principal. Além disso, é mais uma região paralela por passo, com fork, barreira e redução.

## Solução proposta:

Calcular a energia de cada par dentro do ciclo das forças, reutilizando o inv2 que já existe.
O Potential() passa só a devolver o valor guardado. Como o ciclo das forças percorre todos os pares i ≠ j (cada par 2 vezes)
, a soma já é o “2 × Pot” do original, e basta multiplicar por 4ε. Para j == i, inv2 = 0, logo a contribuição é 0.

|                  | Tempo total     | CPI    | #I      | Ciclos  | L1 miss | L2 miss | Ops FP  | % ocupação de cores |
| ---------------- | --------------- | ------ | ------- | ------- | ------- | ------- | ------- | ------------------- |
| Antes do update  | 0.468 s         | 1.174  | 36.22 G | 42.52 G | 650.1 M | n/d     | 49.23 G | 94.6 %              |
| Depois do update | 0.408 s         | 1.289  | 28.46 G | 36.68 G | 486.5 M | n/d     | 42.97 G | 93.6 %              |
| Ganho            | −12.8 % (1.15×) | +9.8 % | −21.4 % | −13.7 % | −25.2 % | n/d     | −12.7 % | −1.0 pp             |

Notas:

- **L2 miss:** as runs do `recolhe` não medem `l2d_cache_refill`, por isso não há esse valor para estas duas versões. O único dado de L2 que temos é de antes da fusão (2.8 M misses, 0.22%). Se precisares da coluna, posso dar-te o comando para medir as duas versões.
- **Ops FP** = `fp_dp_scale_ops_spec` + `fp_dp_fixed_ops_spec`.
- **% ocupação** = "CPUs utilized" do perf ÷ 48.
- **O CPI piora** porque as instruções que saíram eram baratas (loads, o ciclo do Potential e as reduções). As que ficam são a cadeia FP do kernel, que é limitada pela latência, como vimos no annotate.
